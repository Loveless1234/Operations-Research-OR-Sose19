#Aufgabe po2
#Ranjit sah, 836261
#Mukaddes karadeniz,808788
#Ekrem Tokgöz,841530

# import the lpsolve library
library(lpSolve)

# objective function
knapsack.obj <-c( 24,13,23,15,16)

#constraints
knapsack.con <- matrix(c(12,7,11,8,9),nrow=1,byrow=TRUE)
knapsack.dir <- c("<=")
knapsack.rhs <- c(26)

#solve
# Wenn wir die Funktion lp aufrufen, setzen wir all.bin = TRUE, um anzuzeigen, dass alle Variablen 0 oder 1 sind
# Wenn wir nur ganzzahlige Werte generell angeben wollten, würden wir all.int = TRUE setzen
# Die Standardeinstellung für beide Optionen ist FALSE
knapsackSolution <- lp("max",knapsack.obj,knapsack.con,knapsack.dir,knapsack.rhs,all.bin=TRUE) 
print("Solution is:")
print(knapsackSolution$solution)
print("Objective function value at solution is:")
print(knapsackSolution$objval)

