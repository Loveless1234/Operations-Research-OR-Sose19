#Aufgabe po7
#Ranjit sah, 836261
#Mukaddes karadeniz,808788
#Ekrem Tokgöz,841530


# import the lpsolve library
library(lpSolve)

# objective function
knapsack.obj <-c(135,139,149 ,150 ,156 ,163 ,173 ,184 ,192 ,201 ,210 ,214 ,221 ,229 ,240)

#constraints
knapsack.con <- matrix(c(70,73,77,80,82,87,90,94,98 ,106,110 ,113 ,115 ,118 ,120),nrow=1,byrow=TRUE)
knapsack.dir <- c("<=")
knapsack.rhs <- c(750)

#solve
# Wenn wir die Funktion lp aufrufen, setzen wir all.bin = TRUE, um anzuzeigen, dass alle Variablen 0 oder 1 sind
# Wenn wir nur ganzzahlige Werte generell angeben wollten, würden wir all.int = TRUE setzen
# Die Standardeinstellung für beide Optionen ist FALSE
knapsackSolution <- lp("max",knapsack.obj,knapsack.con,knapsack.dir,knapsack.rhs,all.bin=TRUE) 
print("Solution is:")
print(knapsackSolution$solution)
print("Objective function value at solution is:")
print(knapsackSolution$objval)

