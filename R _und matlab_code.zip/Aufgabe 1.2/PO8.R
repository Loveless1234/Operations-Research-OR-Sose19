#Aufgabe po8
#Ranjit sah, 836261
#Mukaddes karadeniz,808788
#Ekrem Tokgöz,841530


# import the lpsolve library
library(lpSolve)

# objective function
knapsack.obj <-c(825594,1677009,1676628,1523970,943972,97426,69666 ,1296457, 1679693,1902996, 1844992,1049289,
                 1252836,1319836,953277,2067538,675367,853655,1826027,65731,901489,577243,466257,369261 )

#constraints
knapsack.con <- matrix(c(382745, 799601,909247 ,729069, 467902, 44328, 34610 , 698150 ,823460  ,903959 ,853665 ,551830 ,
                         610856 ,670702,488960 ,951111 ,323046 ,446298 ,931161,31385,496951,264724,224916 ,169684),nrow=1,byrow=TRUE)
knapsack.dir <- c("<=")
knapsack.rhs <- c(6404180)

#solve
# Wenn wir die Funktion lp aufrufen, setzen wir all.bin = TRUE, um anzuzeigen, dass alle Variablen 0 oder 1 sind
# Wenn wir nur ganzzahlige Werte generell angeben wollten, würden wir all.int = TRUE setzen
# Die Standardeinstellung für beide Optionen ist FALSE
knapsackSolution <- lp("max",knapsack.obj,knapsack.con,knapsack.dir,knapsack.rhs,all.bin=TRUE) 
print("Solution is:")
print(knapsackSolution$solution)
print("Objective function value at solution is:")
print(knapsackSolution$objval)
