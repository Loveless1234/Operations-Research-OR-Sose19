%Ranjit sah,836261
%Mukaddes karadeniz,808788
%Ekrem Tokgöz,841530


%Basis
A_B=[1 2 3 0;1 0 0 0;0 1 0 0;0 0 1 1]

%Nicht Basis
A_N=[1 0 0 ;0 1 0 ;0 0 1 ;0 0 0 ]

%Rechte seite vector
b=[4;1;1;1]'



x_B=inv(A_B)*b





