v=[ 24;13;23;15;16]
w=[12;7;11;8;9]
n=5
W=26
[ V,T,Wneed,Wert ] = knapSack( v,w,n,W )